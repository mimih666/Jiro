<?php
// ============================================================
//  conexao.php — Conexão com o banco de dados
//  Incluir este arquivo em qualquer página que precisar do banco:
//  require_once 'conexao.php';
// ============================================================

$host  = "localhost";
$user  = "root";
$senha = "";          // se tiver senha no seu MySQL, coloca aqui
$banco = "jiro";

$conn = new mysqli($host, $user, $senha, $banco);

// Verifica se a conexão falhou
if ($conn->connect_error) {
    die("Erro na conexão com o banco: " . $conn->connect_error);
}

// Define o charset para evitar problemas com acentos
$conn->set_charset("utf8mb4");
?>