<?php

$conn = new mysqli("127.0.0.1", "root", "", "jiro", 3307);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");