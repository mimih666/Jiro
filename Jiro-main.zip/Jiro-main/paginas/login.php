<style>
  html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    overflow: hidden;
  }

  .login-wrapper {
    min-height: 100vh;
    width: 100%;
    margin: 0;
    position: fixed; 
    top: 0;
    left: 0;
  }
</style>

<div class="login-wrapper">

  <div class="login-hero">
  <img src="assets/download.png" style="width:300px;">

    <p class="hero-tagline">Seu dinheiro, sob controle.</p>
    <p class="hero-desc">
      Organize suas finanças de forma simples, rápida e inteligente.
    </p>

  </div>

  <div class="login-form-area">
    <h2>Entrar</h2>
    <p class="sub">Acesse sua conta para continuar</p>

    <form method="POST">
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>

      <div class="form-group">
        <label>Senha</label>
        <input type="password" name="senha" required>
      </div>

      <button class="btn btn-primario">Entrar</button>
    </form>

  <div class="login-dica">
  <p>
    Ainda não tem conta? <strong>Crie uma gratuitamente</strong>
  </p>
</div>
  </div>

</div>