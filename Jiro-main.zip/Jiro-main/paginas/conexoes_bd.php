<?php
// ============================================================
//  conexoes_bd.php — Testes de leitura do banco jiro
// ============================================================
require_once 'conexao.php'; // puxa a conexão do arquivo separado

// ==========================
// READ - Listar todos os usuários
// ==========================
echo "<h2>Lista de usuários</h2>";

$busca = $conn->query("SELECT * FROM usuarios");

if (!$busca) {
    die("Erro na consulta: " . $conn->error);
}

while ($obj = $busca->fetch_object()) {
    echo "ID: "     . $obj->id     . "<br>";
    echo "Nome: "   . $obj->nome   . "<br>";
    echo "E-mail: " . $obj->email  . "<br>";
    echo "Perfil: " . $obj->perfil . "<br>";
    echo "Ativo: "  . ($obj->ativo ? "Sim" : "Não") . "<br>";
    echo "<hr>";
}

// ==========================
// READ - Buscar usuário por e-mail
// ==========================
echo "<h2>Buscar usuário</h2>";

$email_busca = "mi@gmail.com";
$stmt = $conn->prepare("SELECT nome, email, perfil FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email_busca);
$stmt->execute();
$resultado = $stmt->get_result();
$usu = $resultado->fetch_object();

if ($usu) {
    echo "Nome: "   . $usu->nome   . "<br>";
    echo "E-mail: " . $usu->email  . "<br>";
    echo "Perfil: " . $usu->perfil . "<br>";
} else {
    echo "Usuário não encontrado";
}

$stmt->close();
$conn->close();
?>