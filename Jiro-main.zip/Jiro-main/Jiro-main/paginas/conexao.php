<?php
// ============================================================
//  conexao.php — Conexão com o banco de dados JIRO
//  ⚠️ Se der erro de senha, troque "" por "root" ou sua senha
// ============================================================

$conn = new mysqli("127.0.0.1", "root", "", "jiro");

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
