<?php
// ============================================================
//  funcoes.php — Funções do JIRO conectadas ao banco de dados
// ============================================================

require_once __DIR__ . '/paginas/conexao.php';

// ------------------------------------------------------------
// USUÁRIOS
// ------------------------------------------------------------

// Retorna todos os usuários do banco
function getUsuarios() {
    global $conn;
    $resultado = $conn->query("SELECT * FROM usuarios ORDER BY id ASC");
    $lista = [];
    while ($u = $resultado->fetch_assoc()) {
        $lista[] = $u;
    }
    return $lista;
}

// ------------------------------------------------------------
// CATEGORIAS
// ------------------------------------------------------------

// Retorna categorias padrão + categorias do usuário logado
function getCategorias() {
    global $conn;
    $uid = $_SESSION['usuario_id'] ?? 0;

    $sql = "SELECT nome FROM categorias
            WHERE padrao = 1 OR usuario_id = ?
            ORDER BY padrao DESC, nome ASC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $lista = [];
    while ($row = $resultado->fetch_assoc()) {
        $lista[] = $row['nome'];
    }
    return $lista;
}

// Adiciona nova categoria para o usuário logado
function adicionarCategoria($nome) {
    global $conn;
    $nome = limpar($nome);
    $uid  = $_SESSION['usuario_id'] ?? 0;

    if (empty($nome)) return false;

    // Verifica se já existe
    $stmt = $conn->prepare("SELECT id FROM categorias WHERE nome = ? AND (padrao = 1 OR usuario_id = ?)");
    $stmt->bind_param("si", $nome, $uid);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) return false;

    // Insere nova categoria
    $stmt = $conn->prepare("INSERT INTO categorias (nome, usuario_id, padrao) VALUES (?, ?, 0)");
    $stmt->bind_param("si", $nome, $uid);
    return $stmt->execute();
}

// Exclui categoria do usuário logado (não exclui as padrão)
function excluirCategoria($nome) {
    global $conn;
    $uid = $_SESSION['usuario_id'] ?? 0;

    $stmt = $conn->prepare("DELETE FROM categorias WHERE nome = ? AND usuario_id = ? AND padrao = 0");
    $stmt->bind_param("si", $nome, $uid);
    return $stmt->execute();
}

// ------------------------------------------------------------
// MOVIMENTAÇÕES
// ------------------------------------------------------------

// Retorna movimentações — se passar usuario_id, filtra por ele
function getMovimentacoes($usuario_id = null) {
    global $conn;

    if ($usuario_id !== null) {
        $sql  = "SELECT m.*, c.nome AS categoria
                 FROM movimentacoes m
                 LEFT JOIN categorias c ON m.categoria_id = c.id
                 WHERE m.usuario_id = ?
                 ORDER BY m.data DESC, m.id DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $usuario_id);
    } else {
        $sql  = "SELECT m.*, c.nome AS categoria
                 FROM movimentacoes m
                 LEFT JOIN categorias c ON m.categoria_id = c.id
                 ORDER BY m.data DESC, m.id DESC";
        $stmt = $conn->prepare($sql);
    }

    $stmt->execute();
    $resultado = $stmt->get_result();

    $lista = [];
    while ($row = $resultado->fetch_assoc()) {
        $lista[] = $row;
    }
    return $lista;
}

// Insere nova movimentação no banco
function adicionarMovimentacao($usuario_id, $tipo, $valor, $categoria_nome, $data, $descricao) {
    global $conn;

    if (empty($usuario_id) || empty($tipo) || empty($valor) || empty($categoria_nome) || empty($data) || empty($descricao)) {
        return false;
    }
    if (!in_array($tipo, ['entrada', 'saida'])) return false;
    if (!validarValor($valor))                   return false;
    if (!validarData($data))                     return false;

    // Busca o id da categoria pelo nome
    $stmt = $conn->prepare("SELECT id FROM categorias WHERE nome = ? LIMIT 1");
    $stmt->bind_param("s", $categoria_nome);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $categoria_id = $row ? $row['id'] : null;

    // Insere a movimentação
    $sql  = "INSERT INTO movimentacoes (usuario_id, descricao, valor, tipo, categoria_id, data)
             VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $valor = (float) $valor;
    $stmt->bind_param("isdsis", $usuario_id, $descricao, $valor, $tipo, $categoria_id, $data);
    return $stmt->execute();
}

// Exclui movimentação por id (somente do usuário logado)
function deletarMovimentacao($id) {
    global $conn;
    $uid  = $_SESSION['usuario_id'] ?? 0;
    $stmt = $conn->prepare("DELETE FROM movimentacoes WHERE id = ? AND usuario_id = ?");
    $stmt->bind_param("ii", $id, $uid);
    return $stmt->execute();
}

// Edita movimentação existente
function editarMovimentacao($id, $tipo, $valor, $categoria_nome, $data, $descricao) {
    global $conn;

    if (!validarValor($valor) || !validarData($data)) return false;

    // Busca id da categoria
    $stmt = $conn->prepare("SELECT id FROM categorias WHERE nome = ? LIMIT 1");
    $stmt->bind_param("s", $categoria_nome);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $categoria_id = $row ? $row['id'] : null;

    $sql  = "UPDATE movimentacoes SET tipo=?, valor=?, categoria_id=?, data=?, descricao=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $valor = (float) $valor;
    $stmt->bind_param("sdsssi", $tipo, $valor, $categoria_id, $data, $descricao, $id);
    return $stmt->execute();
}

// ------------------------------------------------------------
// AUTENTICAÇÃO
// ------------------------------------------------------------

function validarLogin($email, $senha) {
    global $conn;

    if (empty($email) || empty($senha)) return false;

    // Busca o usuário pelo e-mail (sem comparar senha ainda)
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();

    if (!$usuario) return false;

    // Tenta password_hash (novos cadastros)
    if (password_verify($senha, $usuario['senha'])) {
        return $usuario;
    }

    // Fallback: MD5 (usuários antigos já existentes no banco)
    if ($usuario['senha'] === md5($senha)) {
        // Atualiza automaticamente para hash seguro
        $novoHash = password_hash($senha, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
        $upd->bind_param("si", $novoHash, $usuario['id']);
        $upd->execute();
        return $usuario;
    }

    return false;
}

function iniciarSessao($usuario) {
    $_SESSION['usuario_id']     = $usuario['id'];
    $_SESSION['usuario_nome']   = $usuario['nome'];
    $_SESSION['usuario_email']  = $usuario['email'];
    $_SESSION['usuario_perfil'] = $usuario['perfil'];
    $_SESSION['logado']         = true;
}

function logout() {
    session_unset();
    session_destroy();
}

function exigirLogin() {
    if (empty($_SESSION['logado'])) {
        header('Location: index.php?pagina=login');
        exit;
    }
}

function exigirAdmin() {
    exigirLogin();
    if ($_SESSION['usuario_perfil'] !== 'admin') {
        header('Location: index.php?pagina=dashboard');
        exit;
    }
}

function estaLogado() {
    return !empty($_SESSION['logado']);
}

function ehAdmin() {
    return estaLogado() && $_SESSION['usuario_perfil'] === 'admin';
}

// ------------------------------------------------------------
// CÁLCULOS
// ------------------------------------------------------------

function calcularTotal($movimentacoes, $tipo) {
    $total = 0;
    foreach ($movimentacoes as $mov) {
        if ($mov['tipo'] === $tipo) {
            $total += $mov['valor'];
        }
    }
    return $total;
}

function calcularSaldo($movimentacoes) {
    return calcularTotal($movimentacoes, 'entrada') - calcularTotal($movimentacoes, 'saida');
}

function totaisPorCategoria($movimentacoes) {
    $totais = [];
    foreach ($movimentacoes as $mov) {
        if ($mov['tipo'] === 'saida') {
            $cat = $mov['categoria'] ?? 'Sem categoria';
            $totais[$cat] = ($totais[$cat] ?? 0) + $mov['valor'];
        }
    }
    arsort($totais);
    return $totais;
}

function totaisEntradaPorCategoria($movimentacoes) {
    $totais = [];
    foreach ($movimentacoes as $mov) {
        if ($mov['tipo'] === 'entrada') {
            $cat = $mov['categoria'] ?? 'Sem categoria';
            $totais[$cat] = ($totais[$cat] ?? 0) + $mov['valor'];
        }
    }
    arsort($totais);
    return $totais;
}


// ------------------------------------------------------------
// ESTATÍSTICAS DO ADMIN (todas do banco)
// ------------------------------------------------------------

function getEstatisticasSistema() {
    global $conn;

    // Total de usuários (excluindo admin)
    $r = $conn->query("SELECT COUNT(*) AS total FROM usuarios WHERE perfil = 'usuario'");
    $totalUsuarios = $r->fetch_assoc()['total'];

    // Total de movimentações
    $r = $conn->query("SELECT COUNT(*) AS total FROM movimentacoes");
    $totalMovimentacoes = $r->fetch_assoc()['total'];

    // Média
    $mediaMovPorUsuario = $totalUsuarios > 0 ? round($totalMovimentacoes / $totalUsuarios, 1) : 0;

    // Usuários com ao menos 1 movimentação
    $r = $conn->query("SELECT COUNT(DISTINCT usuario_id) AS total FROM movimentacoes");
    $usuariosAtivos = $r->fetch_assoc()['total'];

    // Categoria mais usada
    $r = $conn->query("SELECT c.nome, COUNT(*) AS usos
                       FROM movimentacoes m
                       LEFT JOIN categorias c ON m.categoria_id = c.id
                       GROUP BY c.nome ORDER BY usos DESC LIMIT 1");
    $row = $r->fetch_assoc();
    $categoriaMaisUsada = $row ? $row['nome'] : '—';

    // Contagem por categoria
    $r = $conn->query("SELECT c.nome, COUNT(*) AS usos
                       FROM movimentacoes m
                       LEFT JOIN categorias c ON m.categoria_id = c.id
                       GROUP BY c.nome ORDER BY usos DESC");
    $contCat = [];
    while ($row = $r->fetch_assoc()) {
        $contCat[$row['nome']] = $row['usos'];
    }

    return [
        'total_usuarios'       => $totalUsuarios,
        'total_movimentacoes'  => $totalMovimentacoes,
        'media_mov_usuario'    => $mediaMovPorUsuario,
        'categoria_mais_usada' => $categoriaMaisUsada,
        'usuarios_ativos'      => $usuariosAtivos,
        'contagem_categorias'  => $contCat,
    ];
}

// Exclui usuário (somente se não tiver movimentações)
function excluirUsuario($id) {
    global $conn;

    // Verifica se tem movimentações
    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM movimentacoes WHERE usuario_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    if ($total > 0) return false;

    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// ------------------------------------------------------------
// UTILITÁRIOS
// ------------------------------------------------------------

function limpar($valor) {
    return htmlspecialchars(trim($valor), ENT_QUOTES, 'UTF-8');
}

function validarValor($valor) {
    return is_numeric($valor) && $valor > 0;
}

function validarData($data) {
    $d = DateTime::createFromFormat('Y-m-d', $data);
    return $d && $d->format('Y-m-d') === $data;
}

function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

function formatarData($data) {
    $d = DateTime::createFromFormat('Y-m-d', $data);
    return $d ? $d->format('d/m/Y') : $data;
}
