<?php
session_start();

// Se já está logado, vai pro dashboard
if (!empty($_SESSION['logado'])) {
    header('Location: index.php?pagina=dashboard');
    exit;
}

require_once __DIR__ . '/paginas/conexao.php';

$erro   = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome            = trim($_POST['nome'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $senha           = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    // Validações
    if (strlen($nome) < 3) {
        $erro = 'O nome deve ter pelo menos 3 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Informe um e-mail válido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($senha !== $confirmar_senha) {
        $erro = 'As senhas não coincidem.';
    } else {
        // Verifica se e-mail já existe
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $erro = 'Este e-mail já está cadastrado. Tente outro ou faça login.';
        } else {
            // Salva no banco com senha segura
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $insert = $conn->prepare("INSERT INTO usuarios (nome, email, senha, perfil, ativo) VALUES (?, ?, ?, 'usuario', 1)");
            $insert->bind_param("sss", $nome, $email, $senha_hash);

            if ($insert->execute()) {
                header('Location: index.php?pagina=login&cadastro=sucesso');
                exit;
            } else {
                $erro = 'Erro ao criar conta. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta — Jiro</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        html, body {
            margin: 0; padding: 0; height: 100%; overflow: hidden;
        }
        .login-wrapper {
            min-height: 100vh; width: 100%; margin: 0; position: fixed; top: 0; left: 0;
        }
        .campo-linha {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }
        .forca-senha { margin-top: 6px; display: none; }
        .barra-forca { display: flex; gap: 4px; margin-bottom: 4px; }
        .segmento { flex: 1; height: 4px; background: #e0d9f0; border-radius: 2px; transition: background 0.3s; }
        .texto-forca { font-size: 0.75rem; color: #9e9ebb; }
        .msg-campo { font-size: 0.76rem; color: #e53935; margin-top: 4px; display: none; }
        input.invalido { border-color: #e53935 !important; }
    </style>
</head>
<body class="pagina-login">

<div class="login-wrapper">

  <div class="login-hero">
    <img src="assets/css/image.png" style="width:300px;">
    <p class="hero-tagline">Seu dinheiro, sob controle.</p>
    <p class="hero-desc">
      Organize suas finanças de forma simples, rápida e inteligente.
    </p>
  </div>

  <div class="login-form-area">
    <h2>Criar conta</h2>
    <p class="sub">Preencha os dados abaixo para começar</p>

    <?php if (!empty($erro)): ?>
    <div class="alerta alerta-erro">
      ⚠️ <?= htmlspecialchars($erro) ?>
    </div>
    <?php endif; ?>

    <form method="POST" id="formCadastro" novalidate>

      <div class="form-group">
        <label>Nome completo</label>
        <input type="text" id="nome" name="nome"
               value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>"
               placeholder="Seu nome">
        <span class="msg-campo" id="erro-nome">Informe seu nome completo.</span>
      </div>

      <div class="form-group">
        <label>E-mail</label>
        <input type="email" id="email" name="email"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
               placeholder="seu@email.com">
        <span class="msg-campo" id="erro-email">Informe um e-mail válido.</span>
      </div>

      <div class="campo-linha">
        <div class="form-group">
          <label>Senha</label>
          <input type="password" id="senha" name="senha" placeholder="Mínimo 6 caracteres">
          <div class="forca-senha" id="forca-senha">
            <div class="barra-forca">
              <div class="segmento" id="seg1"></div>
              <div class="segmento" id="seg2"></div>
              <div class="segmento" id="seg3"></div>
              <div class="segmento" id="seg4"></div>
            </div>
            <span class="texto-forca" id="texto-forca"></span>
          </div>
          <span class="msg-campo" id="erro-senha">Mínimo de 6 caracteres.</span>
        </div>

        <div class="form-group">
          <label>Confirmar senha</label>
          <input type="password" id="confirmar_senha" name="confirmar_senha" placeholder="Repita a senha">
          <span class="msg-campo" id="erro-confirmar">As senhas não coincidem.</span>
        </div>
      </div>

      <button type="submit" class="btn btn-primario">Criar minha conta →</button>
    </form>

    <div class="login-dica">
      <p>
        Já tem conta? <a href="index.php?pagina=login"><strong>Entrar agora</strong></a>
      </p>
    </div>
  </div>

</div>

<script>
// FORÇA DA SENHA
document.getElementById('senha').addEventListener('input', function () {
    const senha = this.value;
    const container = document.getElementById('forca-senha');
    const segs = ['seg1','seg2','seg3','seg4'].map(id => document.getElementById(id));
    const texto = document.getElementById('texto-forca');

    if (!senha.length) { container.style.display = 'none'; return; }
    container.style.display = 'block';

    let pts = 0;
    if (senha.length >= 6)  pts++;
    if (senha.length >= 10) pts++;
    if (/[A-Z]/.test(senha) && /[0-9]/.test(senha)) pts++;
    if (/[^A-Za-z0-9]/.test(senha)) pts++;

    const cores   = ['#e53935','#fb8c00','#fdd835','#43a047'];
    const textos  = ['Fraca','Razoável','Boa','Forte'];

    segs.forEach((s, i) => s.style.background = i < pts ? cores[pts-1] : '#e0d9f0');
    texto.textContent = textos[pts-1] || 'Fraca';
    texto.style.color = cores[pts-1] || '#e53935';
});

// VALIDAÇÃO FRONTEND
document.getElementById('formCadastro').addEventListener('submit', function (e) {
    let ok = true;

    const limpa = (inputId, msgId) => {
        document.getElementById(inputId).classList.remove('invalido');
        document.getElementById(msgId).style.display = 'none';
    };
    const falha = (inputId, msgId) => {
        document.getElementById(inputId).classList.add('invalido');
        document.getElementById(msgId).style.display = 'block';
        ok = false;
    };

    ['nome','email','senha','confirmar_senha'].forEach(id =>
        limpa(id, 'erro-' + (id === 'confirmar_senha' ? 'confirmar' : id))
    );

    const nome     = document.getElementById('nome').value.trim();
    const email    = document.getElementById('email').value.trim();
    const senha    = document.getElementById('senha').value;
    const confirma = document.getElementById('confirmar_senha').value;

    if (nome.length < 3)                                  falha('nome',            'erro-nome');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))       falha('email',           'erro-email');
    if (senha.length < 6)                                 falha('senha',           'erro-senha');
    if (senha !== confirma)                               falha('confirmar_senha', 'erro-confirmar');

    if (!ok) e.preventDefault();
});
</script>

</body>
</html>
